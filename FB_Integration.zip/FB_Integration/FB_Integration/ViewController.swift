
import UIKit
import FBSDKLoginKit
import Alamofire

class ViewController: UIViewController, FBSDKLoginButtonDelegate {

    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    var dict : [String : AnyObject]!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let loginButton = FBSDKLoginButton()
        loginButton.center = self.view.center;
        loginButton.readPermissions = ["email","user_friends"]
        self.view.addSubview(loginButton)
        
        if (FBSDKAccessToken.current()) != nil{
            getFBUserData()
        }
        
        imgView.clipsToBounds = true
        imgView.layer.cornerRadius = 75

    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        
        print("Login completed")
        getFBUserData()
    }
    func loginButtonWillLogin(_ loginButton: FBSDKLoginButton!) -> Bool {
        
        return true
    }
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
        print("user Logedout")
    }
    
   //function is fetching the user data
    
    func getFBUserData() {
        let graphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"id, email, name, birthday,picture.width(480).height(480)"])
        graphRequest?.start(completionHandler: { (connection, result, error) in
            if error != nil {
                print("Error",error!.localizedDescription)
            }
            else{
                print(result!)
                let field = result! as? [String:Any]
                self.userNameLabel.text = "Hello! " + (field?["name"] as! String)
                if let imageURL = ((field!["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                    print(imageURL)
                    let url = URL(string: imageURL)
                    let data = NSData(contentsOf: url!)
                    let image = UIImage(data: data! as Data)
                    self.imgView.image = image
                }
            }
        })
    }
    
    @IBAction func btnShowFriends(_ sender: Any) {
    
       // showFriends()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
}

